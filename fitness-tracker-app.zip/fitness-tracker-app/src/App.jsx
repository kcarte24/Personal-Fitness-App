import { useState, useEffect } from "react";

const defaultRoutine = {
  name: "Upper Body A",
  exercises: [
    { name: "Lat Pulldown", sets: ["", "", "", ""] },
    { name: "Dumbbell Curls", sets: ["", "", ""] },
  ],
};

export default function App() {
  const [routines, setRoutines] = useState(() => {
    const saved = localStorage.getItem("routines");
    return saved ? JSON.parse(saved) : [defaultRoutine];
  });

  const [today, setToday] = useState(() => {
    const saved = localStorage.getItem("today");
    return saved ? JSON.parse(saved) : null;
  });

  const [newRoutine, setNewRoutine] = useState("");
  const [newTask, setNewTask] = useState("");
  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem("tasks");
    return saved ? JSON.parse(saved) : ["Drink 100oz Water", "Log Protein"];
  });

  const [photos, setPhotos] = useState(() => {
    const saved = localStorage.getItem("photos");
    return saved ? JSON.parse(saved) : [];
  });

  const [weights, setWeights] = useState(() => {
    const saved = localStorage.getItem("weights");
    return saved ? JSON.parse(saved) : [];
  });

  const [newWeight, setNewWeight] = useState("");

  const [schedule, setSchedule] = useState(() => {
    const saved = localStorage.getItem("schedule");
    return saved
      ? JSON.parse(saved)
      : {
          Monday: "Upper Body A",
          Tuesday: "Lower Body",
          Wednesday: "Rest",
          Thursday: "Upper Body B",
          Friday: "Cardio",
        };
  });

  const [darkMode, setDarkMode] = useState(false);
  const [selectedPhotoIndexes, setSelectedPhotoIndexes] = useState([]);

  useEffect(() => {
    localStorage.setItem("routines", JSON.stringify(routines));
    localStorage.setItem("today", JSON.stringify(today));
    localStorage.setItem("tasks", JSON.stringify(tasks));
    localStorage.setItem("schedule", JSON.stringify(schedule));
    localStorage.setItem("photos", JSON.stringify(photos));
    localStorage.setItem("weights", JSON.stringify(weights));
  }, [routines, today, tasks, schedule, photos, weights]);

  const logSet = (routineIdx, exerciseIdx, setIdx, value) => {
    const updated = [...routines];
    updated[routineIdx].exercises[exerciseIdx].sets[setIdx] = value;
    setRoutines(updated);
  };

  const addRoutine = () => {
    if (newRoutine.trim() === "") return;
    const newEntry = { name: newRoutine, exercises: [] };
    setRoutines([...routines, newEntry]);
    setNewRoutine("");
  };

  const updateExerciseName = (routineIdx, exerciseIdx, name) => {
    const updated = [...routines];
    updated[routineIdx].exercises[exerciseIdx].name = name;
    setRoutines(updated);
  };

  const addExercise = (routineIdx) => {
    const updated = [...routines];
    updated[routineIdx].exercises.push({ name: "", sets: ["", "", ""] });
    setRoutines(updated);
  };

  const uploadPhoto = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setPhotos([...photos, { date: new Date().toISOString(), url: reader.result }]);
    };
    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const toggleSelectPhoto = (idx) => {
    setSelectedPhotoIndexes((prev) => {
      if (prev.includes(idx)) return prev.filter((i) => i !== idx);
      if (prev.length === 2) return [prev[1], idx];
      return [...prev, idx];
    });
  };

  const addWeight = () => {
    if (newWeight.trim() === "") return;
    setWeights([...weights, { date: new Date().toISOString(), value: parseFloat(newWeight) }]);
    setNewWeight("");
  };

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  return (
    <main
      style={{
        padding: "1rem",
        maxWidth: "400px",
        margin: "0 auto",
        backgroundColor: darkMode ? "#121212" : "#fff",
        color: darkMode ? "#eee" : "#111",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ fontSize: "1.5rem" }}>Fitness Tracker</h1>
        <label style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <span style={{ fontSize: "0.9rem" }}>Dark Mode</span>
          <input
            type="checkbox"
            checked={darkMode}
            onChange={() => setDarkMode(!darkMode)}
          />
        </label>
      </div>

      <h2 style={{ fontSize: "1.25rem", marginTop: "1.5rem" }}>Today's Workout</h2>
      {today ? (
        <div
          style={{
            border: "1px solid #ccc",
            borderRadius: "6px",
            padding: "1rem",
            marginBottom: "1rem",
            backgroundColor: darkMode ? "#222" : "#f9f9f9",
          }}
        >
          <h3 style={{ fontSize: "1.1rem", marginBottom: "0.5rem" }}>{today.name}</h3>
          {today.exercises.map((ex, exIdx) => (
            <div key={exIdx} style={{ marginBottom: "1rem" }}>
              <input
                type="text"
                value={ex.name}
                onChange={(e) => updateExerciseName(0, exIdx, e.target.value)}
                placeholder="Exercise Name"
                style={{
                  width: "100%",
                  padding: "0.25rem 0.5rem",
                  fontWeight: "600",
                  marginBottom: "0.5rem",
                }}
              />
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "0.5rem" }}>
                {ex.sets.map((set, setIdx) => (
                  <input
                    key={setIdx}
                    placeholder={`Set ${setIdx + 1}`}
                    value={routines[0].exercises[exIdx].sets[setIdx]}
                    onChange={(e) => logSet(0, exIdx, setIdx, e.target.value)}
                    style={{ padding: "0.25rem 0.5rem" }}
                  />
                ))}
              </div>
            </div>
          ))}
          <button onClick={() => addExercise(0)} style={{ padding: "0.4rem 0.8rem" }}>
            + Add Exercise
          </button>
        </div>
      ) : (
        <button
          onClick={() => setToday(routines[0])}
          style={{ padding: "0.5rem 1rem", marginBottom: "1rem" }}
        >
          Start Workout
        </button>
      )}

      <section>
        <h2 style={{ fontSize: "1.25rem", marginTop: "1.5rem" }}>Routine Manager</h2>
        <ul style={{ marginLeft: "1.25rem", marginTop: "0.5rem", listStyleType: "disc" }}>
          {routines.map((routine, idx) => (
            <li key={idx}>{routine.name}</li>
          ))}
        </ul>
        <div style={{ marginTop: "0.5rem", display: "flex", gap: "0.5rem" }}>
          <input
            type="text"
            value={newRoutine}
            onChange={(e) => setNewRoutine(e.target.value)}
            placeholder="New Routine Name"
            style={{ flex: "1", padding: "0.3rem 0.5rem" }}
          />
          <button onClick={addRoutine} style={{ padding: "0.4rem 0.8rem" }}>
            Add
          </button>
        </div>
      </section>

      <section>
        <h2 style={{ fontSize: "1.25rem", marginTop: "1.5rem" }}>Weekly Schedule</h2>
        <ul style={{ marginTop: "0.5rem", paddingLeft: "0" }}>
          {days.map((day) => (
            <li
              key={day}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "0.3rem",
              }}
            >
              <span>{day}:</span>
              <select
                value={schedule[day] || ""}
                onChange={(e) => setSchedule({ ...schedule, [day]: e.target.value })}
                style={{ padding: "0.3rem" }}
              >
                <option value="">--None--</option>
                {routines.map((r, idx) => (
                  <option key={idx} value={r.name}>
                    {r.name}
                  </option>
                ))}
              </select>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 style={{ fontSize: "1.25rem", marginTop: "1.5rem" }}>Daily Tasks</h2>
        <ul
          style={{
            marginLeft: "1.25rem",
            marginTop: "0.5rem",
            listStyleType: "disc",
            paddingLeft: "0",
          }}
        >
          {tasks.map((task, idx) => (
            <li
              key={idx}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "0.5rem",
                marginBottom: "0.25rem",
              }}
            >
              <input
                type="text"
                value={task}
                onChange={(e) => {
                  const newTasks = [...tasks];
                  newTasks[idx] = e.target.value;
                  setTasks(newTasks);
                }}
                style={{ flex: "1", padding: "0.25rem 0.5rem" }}
              />
              <button
                onClick={() => setTasks(tasks.filter((_, i) => i !== idx))}
                style={{ padding: "0.25rem 0.5rem" }}
                title="Remove task"
              >
                ✓
              </button>
            </li>
          ))}
        </ul>
        <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.5rem" }}>
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="New Task"
            style={{ flex: "1", padding: "0.3rem 0.5rem" }}
          />
          <button
            onClick={() => {
              if (newTask.trim()) {
                setTasks([...tasks, newTask]);
                setNewTask("");
              }
            }}
            style={{ padding: "0.4rem 0.8rem" }}
          >
            Add
          </button>
        </div>
      </section>

      <section>
        <h2 style={{ fontSize: "1.25rem", marginTop: "1.5rem" }}>Weight Tracking</h2>
        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.5rem" }}>
          <input
            type="number"
            value={newWeight}
            onChange={(e) => setNewWeight(e.target.value)}
            placeholder="Enter weight (lbs)"
            style={{ flex: "1", padding: "0.3rem 0.5rem" }}
          />
          <button onClick={addWeight} style={{ padding: "0.4rem 0.8rem" }}>
            Log
          </button>
        </div>
        <ul style={{ marginTop: "0", paddingLeft: "1.25rem" }}>
          {weights.map((entry, idx) => (
            <li key={idx} style={{ fontSize: "0.9rem" }}>
              {new Date(entry.date).toLocaleDateString()}: {entry.value} lbs
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 style={{ fontSize: "1.25rem", marginTop: "1.5rem" }}>Weekly Progress Photos</h2>
        <input type="file" accept="image/*" onChange={uploadPhoto} style={{ marginTop: "0.5rem" }} />
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "0.5rem",
            marginTop: "0.5rem",
          }}
        >
          {photos.map((photo, idx) => (
            <img
              key={idx}
              src={photo.url}
              alt="Progress"
              onClick={() => toggleSelectPhoto(idx)}
              style={{
                width: "100%",
                cursor: "pointer",
                borderRadius: "6px",
                border: selectedPhotoIndexes.includes(idx)
                  ? "3px solid #3b82f6"
                  : "3px solid transparent",
              }}
            />
          ))}
        </div>
        {selectedPhotoIndexes.length === 2 && (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: "1rem",
              marginTop: "1rem",
            }}
          >
            {selectedPhotoIndexes.map((idx) => (
              <div key={idx}>
                <p style={{ fontSize: "0.8rem", textAlign: "center" }}>
                  {new Date(photos[idx].date).toLocaleDateString()}
                </p>
                <img
                  src={photos[idx].url}
                  alt="Comparison"
                  style={{ width: "100%", borderRadius: "6px" }}
                />
              </div>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
