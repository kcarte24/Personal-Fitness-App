export default {
  root: '.',
};